﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Test1_CLDV.Services
{
    public class Item_Masterfile
    {
        [Key]
        public string SKU_Number { get; set; } = "";
        [MaxLength(50)]
        public string Product_Name { get; set; } = "";
        [MaxLength(100)]
        public string Product_Description { get; set; } = "";
        [Precision(6,2)]
        public string Price { get; set; } = "";
    }
}
