﻿using Microsoft.EntityFrameworkCore;
using Test1_CLDV.Models;

namespace Test1_CLDV.Services
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {

        }
        public  DbSet<Item_Masterfile> Items { get; set; }

    }

}
