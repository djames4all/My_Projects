CREATE TABLE Item_Masterfile(
SKU_Number INT NOT NULL PRIMARY KEY IDENTITY,
PRODUCT_NAME VARCHAR(50) NOT NULL,
PRODUCT_DESCRIPTION VARCHAR(100) NOT NULL,
PRICE DECIMAL(4, 2) NOT NULL
);
SET IDENTITY_INSERT Item_Masterfile ON;
SET IDENTITY_INSERT Item_Masterfile OFF;


INSERT INTO Item_Masterfile (SKU_Number, Product_Name, Product_Description, Price) VALUES
(1001,'Hand Gesture Art', 'Canvas art for your home', '300.00'),
(1002,'Incense Burner', 'For fresh and clean air', '150.00'),
(1003,'Embroided Earrings', 'Suitable for outings', '400.00'),
(1004,'Rainbow Handbag', 'Designed for everyday use', '820.00');

SET IDENTITY_INSERT Cart ON;
SET IDENTITY_INSERT Cart OFF;

CREATE TABLE Cart (
    Cart_ID INT NOT NULL PRIMARY KEY IDENTITY,
    SKU_Number INT NOT NULL,
    Product_Description VARCHAR(100) NOT NULL,
    Price DECIMAL(4, 2) NOT NULL,
    Quantity INT NOT NULL,
    Total AS (Price * Quantity) PERSISTED,
    FOREIGN KEY (SKU_Number) REFERENCES Item_Masterfile(SKU_Number)
);

INSERT INTO Cart (SKU_Number, Product_Description, Price, Quantity) VALUES
(1001, 'Canvas art for your home', 3.00, 3),
(1002, 'For fresh and clean air', 1.00, 2),
(1003, 'Suitable for outings', 4.00, 2),
(1004, 'Designed for everyday use', 8.00, 1);



CREATE TABLE Customer_Masterfile (
    CustomerID INT NOT NULL PRIMARY KEY IDENTITY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(50) NOT NULL UNIQUE CHECK (Email LIKE '%_@_%._%'),
    Password NVARCHAR(255) NOT NULL
);

SET IDENTITY_INSERT Customer_Masterfile ON;
SET IDENTITY_INSERT Customer_Masterfile OFF;

INSERT INTO Customer_Masterfile (CustomerID, FirstName, LastName, Email, Password) VALUES
(9001,'Daniel', 'James', 'daniel@gmail.com', 'qwerty'),
(9002,'Sai', 'Surujpal', 'sai@gmail.com', 'asdf'),
(9003,'Amy', 'Dhanilal', 'amy@gmail.com', 'zxcv'),
(9004,'Ethan', 'Jones', 'ethan@gmail.com', 'qazwsx');

CREATE TABLE Customer_Payments (
    CustomerID INT NOT NULL PRIMARY KEY IDENTITY,
    Cardholder_Name VARCHAR(30) NOT NULL,
    CardNumber INT NOT NULL,
    ExpiryDate DATE NOT NULL,
    CVV INT NOT NULL
);


SET IDENTITY_INSERT Customer_Payments ON;
SET IDENTITY_INSERT Customer_Payments OFF;

INSERT INTO Customer_Payments (CustomerID, Cardholder_Name, CardNumber, ExpiryDate, CVV) VALUES
(9001,'Daniel', '147896523', '2026-04-15', '123'),
(9002,'Sai', '956147823', '2025-06-23', '456'),
(9003,'Amy', '102475316', '2027-10-19', '789'),
(9004,'Ethan', '248957621', '2024-01-11', '147');

CREATE TABLE Login (
    CustomerID INT NOT NULL,
    Email VARCHAR(50) NOT NULL,
    Password NVARCHAR(30) NOT NULL,
    PRIMARY KEY (CustomerID),
    FOREIGN KEY (CustomerID) REFERENCES Customer_Masterfile(CustomerID),
    FOREIGN KEY (Email) REFERENCES Customer_Masterfile(Email)
);


INSERT INTO Login (CustomerID, Email, Password) VALUES
(9001,'daniel@gmail.com', 'qwerty'),
(9002,'sai@gmail.com', 'asdf'),
(9003,'amy@gmail.com', 'zxcv'),
(9004,'ethan@gmail.com', 'qazwsx');


CREATE TABLE Forgot_Password (
    CustomerID INT NOT NULL,
    Email VARCHAR(50) NOT NULL,
    Password NVARCHAR(30) NOT NULL,
    PRIMARY KEY (CustomerID),
    FOREIGN KEY (CustomerID) REFERENCES Customer_Masterfile(CustomerID),
    FOREIGN KEY (Email) REFERENCES Customer_Masterfile(Email)
);

INSERT INTO Forgot_Password (CustomerID, Email, Password) VALUES
(9001,'daniel@gmail.com', 'qwerty'),
(9002,'sai@gmail.com', 'asdf'),
(9003,'amy@gmail.com', 'zxcv'),
(9004,'ethan@gmail.com', 'qazwsx');


-- Create the Contact_Forms table
CREATE TABLE Contact_Forms (
    FormID INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(50) NOT NULL,
    Surname VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    ContactNumber VARCHAR(10) NOT NULL,
    SKU_Number INT NOT NULL,
    Message VARCHAR(MAX)
);

SET IDENTITY_INSERT Contact_Forms ON;
SET IDENTITY_INSERT Contact_Forms OFF;

INSERT INTO Contact_Forms (FormID, Name, Surname, Email, ContactNumber, SKU_Number, Message) VALUES
(8001,'Daniel', 'James', 'daniel@gmail.com', 0724986753, '1001', 'How much is the products'),
(8002,'Sai', 'Surujpal', 'sai@gmail.com', 0846984136, '1002', 'What date will it be delivery'),
(8003,'Amy', 'Dhanilal', 'amy@gmail.com', 0721489632 , '1003', 'How many colours does it come in'),
(8004,'Ethan', 'Jones', 'ethan@gmail.com', 0826987412, '1004' , 'Is this a stong product');

-- Create the Contact_Forms_Admin table
CREATE TABLE Contact_Forms_Admin (
    FormID INT NOT NULL PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Surname VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    ContactNumber VARCHAR(20) NOT NULL,
    SKU_Number INT NOT NULL,
    Message VARCHAR(MAX),
    Admin_Message VARCHAR(MAX),
    FOREIGN KEY (FormID) REFERENCES Contact_Forms(FormID)
);

SELECT FormID FROM Contact_Forms WHERE FormID IN (8001, 8002, 8003, 8004);
INSERT INTO Contact_Forms_Admin (FormID, Name, Surname, Email, ContactNumber, SKU_Number, Message, Admin_Message) VALUES
(8001,'Daniel', 'James', 'daniel@gmail.com', 0724986753, '1001', 'How much is the products', 'The product is R300.00'),
(8002,'Sai', 'Surujpal', 'sai@gmail.com', 0846984136, '1002', 'What date will it be delivery', 'ETA is five working days' ),
(8003,'Amy', 'Dhanilal', 'amy@gmail.com', 0721489632 , '1003', 'How many colours does it come in', 'The product is multi coloured'),
(8004,'Ethan', 'Jones', 'ethan@gmail.com', 0826987412, '1004' , 'Is this a stong product', 'Yes very stong');

-- Create the 'Orders' Table
CREATE TABLE Orders (
    OrderNumber INT NOT NULL PRIMARY KEY IDENTITY,
    CustomerName VARCHAR(50) NOT NULL, -- Assuming this is obtained from Cart table
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    Status VARCHAR(20) NOT NULL
);

SET IDENTITY_INSERT Orders ON;
SET IDENTITY_INSERT Orders OFF;

INSERT INTO Orders (OrderNumber, CustomerName, OrderDate, Status) VALUES
(7001,'Daniel', '2024-04-19', 'Pending'),
(7002,'Sai', '2024-05-12', 'Pending'),
(7003,'Amy', '2024-05-15', 'Pending'),
(7004,'Ethan', '2024-04-21', 'Pending');

-- Create the 'Orders_Admin' Table
CREATE TABLE Orders_Admin (
    OrderNumber INT NOT NULL PRIMARY KEY,
    CustomerName VARCHAR(50) NOT NULL, -- Assuming this is obtained from Cart table
    OrderDate DATETIME NOT NULL,
    Status VARCHAR(20) NOT NULL,
    FOREIGN KEY (OrderNumber) REFERENCES Orders(OrderNumber)
);

INSERT INTO Orders_Admin (OrderNumber, CustomerName, OrderDate, Status) VALUES
(7001,'Daniel', '2024-04-19', 'Processed'),
(7002,'Sai', '2024-05-12', 'Processed'),
(7003,'Amy', '2024-05-15', 'Pending'),
(7004,'Ethan', '2024-04-21', 'Pending');

-- Create the 'Order_Details' Table
CREATE TABLE Order_Details (
    OrderNumber INT NOT NULL,
    SKU_Number INT NOT NULL,
    Quantity INT NOT NULL,
    TotalPrice DECIMAL(4, 2) NOT NULL, -- Assuming this is obtained from Cart table
    PRIMARY KEY (OrderNumber, SKU_Number), -- Composite primary key
    FOREIGN KEY (OrderNumber) REFERENCES Orders(OrderNumber),
    FOREIGN KEY (SKU_Number) REFERENCES Item_Masterfile(SKU_Number)
);


SELECT OrderNumber FROM Orders;
INSERT INTO Order_Details (OrderNumber, SKU_Number, Quantity, TotalPrice) VALUES
(7001, 1001, 3, '900.00'),
(7002, 1002, 2, '300.00'),
(7003, 1003, 2, '800.00'),
(7004, 1004, 1, '820.00');

-- Create the 'Order_Details_Admin' Table
CREATE TABLE Order_Details_Admin (
    OrderNumber INT NOT NULL,
    SKU_Number INT NOT NULL,
    Quantity INT NOT NULL,
    TotalPrice DECIMAL(4, 2) NOT NULL, -- Assuming this is obtained from Cart table
    FOREIGN KEY (OrderNumber) REFERENCES Orders_Admin(OrderNumber),
    FOREIGN KEY (SKU_Number) REFERENCES Item_Masterfile(SKU_Number)
);

SELECT OrderNumber FROM Orders;
INSERT INTO Order_Details_Admin (OrderNumber, SKU_Number, Quantity, TotalPrice) VALUES
(7001, 1001, 3, '900.00'),
(7002, 1002, 2, '300.00'),
(7003, 1003, 2, '800.00'),
(7004, 1004, 1, '820.00');

-- Alter the Login table to change the length of the Password column
ALTER TABLE Login
ALTER COLUMN Password NVARCHAR(30);

-- Alter the Contact_Forms_Admin table to change the length of the ContactNumber column
ALTER TABLE Contact_Forms_Admin
ALTER COLUMN ContactNumber VARCHAR(10);

-- Alter the Order_Details_Admin table to change the precision and scale of the TotalPrice column
ALTER TABLE Order_Details_Admin
ALTER COLUMN TotalPrice DECIMAL(6, 2);

ALTER TABLE Customer_Masterfile
ALTER COLUMN Email VARCHAR(50) NOT NULL;

ALTER TABLE Customer_Masterfile
ADD CONSTRAINT CK_EmailFormat CHECK (Email LIKE '%_@_%._%');

CREATE INDEX IX_Cart_SKU_Number ON Cart (SKU_Number);

-- Alter Customer_Masterfile table to add unique constraint on Email column
ALTER TABLE Customer_Masterfile
ADD CONSTRAINT UC_Customer_Masterfile_Email UNIQUE (Email);

-- Alter Login table to add unique constraint on Email column
ALTER TABLE Login
ADD CONSTRAINT UC_Login_Email UNIQUE (Email);

-- Alter Forgot_Password table to add unique constraint on Email column
ALTER TABLE Forgot_Password
ADD CONSTRAINT UC_Forgot_Password_Email UNIQUE (Email);

ALTER TABLE Item_Masterfile
ALTER COLUMN PRICE DECIMAL(6, 2) NOT NULL;

ALTER TABLE Order_Details
ALTER COLUMN TotalPrice DECIMAL(6, 2) NOT NULL;

ALTER TABLE Order_Details_Admin
ALTER COLUMN TotalPrice DECIMAL(6, 2) NOT NULL;

ALTER TABLE Cart
ALTER COLUMN Price DECIMAL(6, 2) NOT NULL;





SELECT * FROM Item_Masterfile;
SELECT * FROM Cart;
SELECT * FROM Customer_Masterfile;
SELECT * FROM Login;
SELECT * FROM Forgot_Password;
SELECT * FROM Contact_Forms;
SELECT * FROM Contact_Forms_Admin;
SELECT * FROM Orders;
SELECT * FROM Orders_Admin;
SELECT * FROM Order_Details;
SELECT * FROM Order_Details_Admin;
















