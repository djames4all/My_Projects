﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Test1_CLDV.Models
{
    public class Customer_Masterfile
    {
        [Key]
        public string CustomerID { get; set; } = "";
        
        [Required, MaxLength(50)]
        public string FirstName { get; set; } = "";

        [Required, MaxLength(50)]
        public string LastName { get; set; } = "";

        [Required, MaxLength(50)]
        public string Email { get; set; } = "";

        [Required, MaxLength(255)]
        public string Password { get; set; } = "";
    }
}
