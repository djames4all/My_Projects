using Azure.Storage.Files.Shares;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Threading.Tasks;
using System;

public static class UploadToFileShareFunction
{
    [FunctionName("UploadToFileShare")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        log.LogInformation("C# HTTP trigger function to upload a file to Azure File Storage.");

        string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
        ShareClient shareClient = new ShareClient(storageConnectionString, "filesharecustomerdet001");
        await shareClient.CreateIfNotExistsAsync();

        ShareDirectoryClient directoryClient = shareClient.GetRootDirectoryClient();
        ShareFileClient fileClient = directoryClient.GetFileClient("uploadedfile.txt");

        using (var stream = new MemoryStream())
        {
            await req.Body.CopyToAsync(stream);
            stream.Position = 0;
            await fileClient.CreateAsync(stream.Length);
            await fileClient.UploadAsync(stream);
        }

        return new OkObjectResult("File uploaded to Azure File Share successfully.");
    }
}
