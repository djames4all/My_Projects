using Azure.Storage.Queues;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.IO;
using System;

public static class QueueFunction
{
    [FunctionName("QueueOperation")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        log.LogInformation("C# HTTP trigger function to write a message to Azure Queue.");

        string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
        QueueClient queueClient = new QueueClient(storageConnectionString, "orderqueue");
        await queueClient.CreateIfNotExistsAsync();

        string message = await new StreamReader(req.Body).ReadToEndAsync();
        await queueClient.SendMessageAsync(message);

        return new OkObjectResult("Message written to Azure Queue successfully.");
    }
}
