﻿using CloudPOE.Models;
using CloudPOE.Services;
using Microsoft.AspNetCore.Mvc;

namespace CloudPOE.Controllers
{
    public class QueueController : Controller
    {
        private readonly AzureQueueService _queueService;

        public QueueController(AzureQueueService queueService)
        {
           _queueService = queueService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Order order)
        {
            {
                order.OrderId = Guid.NewGuid().ToString();
                await _queueService.SendMessageAsync(order);
                return RedirectToAction("Index");
            }
        }
    }
}
