﻿using Microsoft.AspNetCore.Mvc;
using Azure.Data.Tables;
using CloudPOE.Models;
using CloudPOE.Controllers;
using System.Security.Cryptography.Xml;
using Azure.Storage.Queues;
using System.Text.Json;
using CloudPOE.Services;

namespace CloudPOE.Controllers
{

    public class OrderController : Controller
    {
        private readonly AzureQueueService _queueService;

        public OrderController(AzureQueueService queueService)
        {
            _queueService = queueService;
        }


        public IActionResult Success()
        {
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Order order)
        {
            {
                order.OrderId = Guid.NewGuid().ToString();
                await _queueService.SendMessageAsync(order);
                return RedirectToAction("Success");
            }
        }
    }

}
//    public class OrderController : Controller
//    {
//        private readonly string _storageAccountConnectionString;
//        private readonly string _queueName = "Order";
//        private readonly QueueClient _queueClient;

//        public OrderController(IConfiguration configuration)
//        {
//            _storageAccountConnectionString = configuration["ConnectionString:AzureQueueConnectionString"];
//            _queueClient = new QueueClient(_storageAccountConnectionString, queueName);
//            _queueClient.CreateIfNotExists();

//        }

//        public IActionResult Create()
//        {
//            return View();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Create(Order order)
//        {
//            if (ModelState.IsValid)
//            {
//                string orderMessage = JsonSerializer.Serialize(order);

//                await _queueClient.SendMessageAsync(orderMessage);

//                return RedirectToAction(nameof(Success));
//            }
//            return View(order);
//        }

//        public IActionResult Success()
//        {
//            return View();
//        }
//    }
//}



