﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using CloudPOE.Models;

public class CustomerController : Controller
{
    private readonly HttpClient _httpClient;

    public CustomerController(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(Customer customer)
    {
        if (ModelState.IsValid)
        {
            var content = new StringContent(JsonConvert.SerializeObject(customer), Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _httpClient.PostAsync("https://cloudpoefunctionspart2.azurewebsites.net/api/StoreInTable", content);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Success");
            }
        }

        return View(customer);
    }

    public IActionResult Success()
    {
        return View();
    }
}
