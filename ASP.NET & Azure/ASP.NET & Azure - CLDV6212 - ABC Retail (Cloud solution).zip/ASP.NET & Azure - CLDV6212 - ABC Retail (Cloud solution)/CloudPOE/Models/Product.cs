﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace CloudPOE.Models
{
    public class Product : ITableEntity
    {
        public string PartitionKey { get; set; } = "product";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        [Required]
        public string SkuNumber { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Descripton { get; set; }
        [Required]
        public string Price { get; set; }
        [Required]
        public string Quantity { get; set; }


    }
}
