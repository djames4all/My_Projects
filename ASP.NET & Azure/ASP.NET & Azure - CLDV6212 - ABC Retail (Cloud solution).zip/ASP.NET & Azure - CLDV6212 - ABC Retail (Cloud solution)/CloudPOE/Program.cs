using Azure.Storage.Blobs;
using CloudPOE.Services;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("AzureQueueConnectionString");

var queueName = builder.Configuration["AzureQueueSettings:QueueName"];

builder.Services.AddSingleton(new AzureQueueService(connectionString, queueName));

// Add services to the container.
builder.Services.AddControllersWithViews();

var blobServiceClient = new BlobServiceClient
(builder.Configuration.GetConnectionString("AzureBlobStorage"));
builder.Services.AddSingleton(blobServiceClient);
builder.Services.AddScoped<AzureBlobService>();
builder.Services.AddHttpClient();


builder.Services.AddTransient<AzureFileService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
