﻿using Azure.Storage.Blobs;

namespace CloudPOE.Services
{
    public class AzureBlobService
    {
        private readonly BlobServiceClient _blobServiceClient;
        public AzureBlobService(BlobServiceClient blobServiceClient)
        {
            _blobServiceClient = blobServiceClient;
        }

        public async Task<string> UploadFileAsync(IFormFile file, string containerName)
        {
            var containerClinet = _blobServiceClient.GetBlobContainerClient(containerName);
            await containerClinet.CreateIfNotExistsAsync();
            var blobClient = containerClinet.GetBlobClient(file.FileName);

            await using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream, true);
            }

            return blobClient.Uri.ToString();
        }
    }
}
