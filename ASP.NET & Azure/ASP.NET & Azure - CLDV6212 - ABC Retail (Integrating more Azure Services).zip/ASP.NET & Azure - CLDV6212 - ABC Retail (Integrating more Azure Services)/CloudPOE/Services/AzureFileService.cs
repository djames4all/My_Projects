﻿using Azure.Storage.Files.Shares;


    public class AzureFileService
    {

    private readonly string _accountName;
    private readonly string _fileShareName;
    private readonly string _accountKey;

    public AzureFileService(IConfiguration configuration)
    {
        _accountName = configuration["AzureFileStorage:AccountName"];
        _fileShareName = configuration["AzureFileStorage:FileShareName"];
        _accountKey = configuration["AzureFileStorage:AccountKey"];
    }

    public async Task UploadFileAsync(string fileName, Stream fileStream)
    {
        var shareUri = new Uri($"https://{_accountName}.file.core.windows.net/{_fileShareName}");
        var shareClient = new ShareClient(shareUri, new Azure.Storage.StorageSharedKeyCredential(_accountName, _accountKey));

        await shareClient.CreateIfNotExistsAsync();
        var rootDirectory = shareClient.GetRootDirectoryClient();
        var fileClient = rootDirectory.GetFileClient(fileName);

        await fileClient.CreateAsync(fileStream.Length);
        await fileClient.UploadRangeAsync(new Azure.HttpRange(0, fileStream.Length), fileStream);
    }
}

