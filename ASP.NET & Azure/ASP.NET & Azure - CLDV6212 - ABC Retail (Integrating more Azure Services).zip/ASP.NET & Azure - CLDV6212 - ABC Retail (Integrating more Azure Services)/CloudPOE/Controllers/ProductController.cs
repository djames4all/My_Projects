﻿using Microsoft.AspNetCore.Mvc;
using Azure.Data.Tables;
using CloudPOE.Models;
using CloudPOE.Controllers;
using System.Security.Cryptography.Xml;

namespace CloudPOE.Controllers
{
    public class ProductController : Controller
    {
        private readonly string _storageAccountConnectionString;
        private readonly string _tableName = "Products";
        private readonly TableClient _tableClient;

        public ProductController(IConfiguration configuration)
        {
            _storageAccountConnectionString = configuration["AzureStorage:ConnectionString"];
            _tableClient = new TableClient(_storageAccountConnectionString, _tableName);
            _tableClient.CreateIfNotExists();

        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create (Product product)
        {
            if (ModelState.IsValid)
            {
                await _tableClient.AddEntityAsync(product);
                return RedirectToAction(nameof(Success));

             }
            return View(product);

        }

        public IActionResult Success()
        {
            return View();
        }
    }
}


       
