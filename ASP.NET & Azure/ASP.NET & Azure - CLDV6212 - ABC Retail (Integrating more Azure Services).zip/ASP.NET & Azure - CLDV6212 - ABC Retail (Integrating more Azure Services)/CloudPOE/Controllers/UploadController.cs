﻿using Microsoft.AspNetCore.Mvc;

public class UploadController : Controller
{

    private readonly AzureFileService _fileService;
    public UploadController(AzureFileService fileService)
    {
        _fileService = fileService;
    }

    [HttpGet]
    public IActionResult Upload()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file != null && file.Length > 0)
        {
            using var stream = file.OpenReadStream();
            await _fileService.UploadFileAsync(file.FileName, stream);
            ViewBag.Message = "File Uploaded Successfully!";
        }

        return View("Upload");
    }
}


