using Azure;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System;

public static class StoreToTableFunction
{
    [FunctionName("StoreToTable")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        log.LogInformation("C# HTTP trigger function to store data into Azure Tables.");

        // Connection string and table name (can be moved to appsettings)
        string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
        TableClient tableClient = new TableClient(storageConnectionString, "CustomerTable");

        await tableClient.CreateIfNotExistsAsync();

        var customer = new TableEntity("Customer", "001")
        {
            { "Name", "Daniel James" },
            { "Email", "djames@gmail.com" }
        };

        await tableClient.AddEntityAsync(customer);

        return new OkObjectResult("Customer entity stored in Azure Table successfully.");
    }
}
