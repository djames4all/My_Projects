using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Threading.Tasks;
using System;

public static class UploadToBlobFunction
{
    [FunctionName("UploadToBlob")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        log.LogInformation("C# HTTP trigger function to upload a file to Azure Blob Storage.");

        string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
        var blobServiceClient = new BlobServiceClient(storageConnectionString);
        var containerClient = blobServiceClient.GetBlobContainerClient("mediablob");
        await containerClient.CreateIfNotExistsAsync();

        string blobName = "sample.txt";
        var blobClient = containerClient.GetBlobClient(blobName);

        using (var stream = new MemoryStream())
        {
            await req.Body.CopyToAsync(stream);
            stream.Position = 0;
            await blobClient.UploadAsync(stream, true);
        }

        return new OkObjectResult("File uploaded to Blob Storage successfully.");
    }
}
