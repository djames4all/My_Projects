﻿using Microsoft.AspNetCore.Mvc;
using CloudPOE.Services;


namespace CloudPOE.Controllers
{
    public class BlobController : Controller
    {

        private readonly AzureBlobService _azureBlobService;

        public BlobController(AzureBlobService azureBlobService)
        {
            _azureBlobService = azureBlobService;
        }
        public IActionResult Blob()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Blob(IFormFile file)
        {
            if (file != null)
            {
                var result = await _azureBlobService.UploadFileAsync(file, "productimgblob");
                ViewBag.Message = "Image Uploaded Successfully!";
            }

            return View("Blob");
        }
    }
}
