﻿using Microsoft.AspNetCore.Mvc;
using Azure.Data.Tables;
using CloudPOE.Models;
using CloudPOE.Controllers;
using System.Security.Cryptography.Xml;

namespace CloudPOE.Controllers
{
    public class CustomerController : Controller
    {
        private readonly string _storageAccountConnectionString;
        private readonly string _tableName = "Customers";
        private readonly TableClient _tableClient;

        public CustomerController(IConfiguration configuration)
        {
            _storageAccountConnectionString = configuration["AzureStorage:ConnectionString"];
            _tableClient = new TableClient(_storageAccountConnectionString, _tableName);
            _tableClient.CreateIfNotExists();

        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create (Customer customer)
        {
            if (ModelState.IsValid)
            {
                await _tableClient.AddEntityAsync(customer);
                return RedirectToAction(nameof(Success));

             }
            return View(customer);

        }

        public IActionResult Success()
        {
            return View();
        }
    }
}


       
