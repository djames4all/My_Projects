﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace CloudPOE.Models
{
    public class Order : ITableEntity
    {
        public string PartitionKey { get; set; } = "order";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        [Required]
        public string OrderId {  get; set; }
        [Required]
        public string CustomerName { get; set; }
        [Required]
        public string CustomerSurname { get; set; }
        [Required]
        public string SkuNumber { get; set; }
        [Required]
        public string ProductName { get; set; }
        [Required]
        public string ProductQuantity { get; set; }
    }
}
