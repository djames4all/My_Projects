﻿using Azure.Storage.Queues;
using System.Text.Json;

namespace CloudPOE.Services
{
    public class AzureQueueService
    {
        private readonly QueueClient _queueClient;
        public AzureQueueService(string connectionString, string queueName)
        {
            _queueClient = new QueueClient(connectionString, queueName);
            _queueClient.CreateIfNotExists();
        }

        public async Task SendMessageAsync<T> (T Message)
        {
            if(_queueClient.Exists())
            {
                string messageText = JsonSerializer.Serialize(Message);
                await _queueClient.SendMessageAsync
                    (Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(messageText)));
            }  
        }
    }
}


